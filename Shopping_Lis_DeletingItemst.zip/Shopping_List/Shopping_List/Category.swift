//
//  Category.swift
//  Shopping_List
//
//  Created by mobileProg on 12/14/20.
//

import Foundation


struct Category{
    var name : String
    var products : [Product]?
    
    static func loadCategory() ->[Category]{
        
        let Category1 = Category(name:"Fruits & Veggies")
        let Category2 = Category(name:"Dairy Products")
        let Category3 = Category(name:"Grain & Bread")
        let Category4 = Category(name:"Beverages")
        let Category5 = Category(name:"Others")

        return [Category1, Category2, Category3, Category4, Category5]

    }
    
    
}
