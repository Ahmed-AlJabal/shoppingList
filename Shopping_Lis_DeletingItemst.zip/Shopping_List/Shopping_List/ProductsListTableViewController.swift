//
//  ItemsListTableViewController.swift
//  Shopping_List
//
//  Created by mobileProg on 12/14/20.
//

import UIKit

class ProductsListTableViewController: UITableViewController {
    
    //creating a variable to save the products in
    var products = [Product]()
    var fruitsAndVegCategory: [Product] = []
    var beveragesCategory: [Product] = []
    var DairyProductsCategory: [Product] = []
    var GrainandBreadCategory: [Product] = []
    var HouseHoldCategory: [Product] = []
    var OthersCategory: [Product] = []
    
    var categories: [[Product]] = []
        
   
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.rightBarButtonItem = editButtonItem

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        //will check if there is a saved file for products and if there isn't it will load the sample data
        sortingProductsCategory()
        
        

        
    }
    
    
    func sortingProductsCategory(){
        fruitsAndVegCategory.removeAll()
        beveragesCategory.removeAll()
        DairyProductsCategory.removeAll()
        GrainandBreadCategory.removeAll()
        HouseHoldCategory.removeAll()
        OthersCategory.removeAll()
        
        if let savedItems = Product.loadProducts(){
            products = savedItems
        }
        else{
            products = Product.loadSampleProducts()
        }
        
        for product in products {
            if product.category == Product.categories[0] {
                fruitsAndVegCategory.append(product)
            }else if product.category == Product.categories[1] {
                beveragesCategory.append(product)
            }else if product.category == Product.categories[2]{
                DairyProductsCategory.append(product)
            }else if product.category == Product.categories[3]{
                GrainandBreadCategory.append(product)
            }else if product.category == Product.categories[4]{
                HouseHoldCategory.append(product)
            }else if product.category == Product.categories[5]{
                OthersCategory.append(product)
            }
        }
        
        categories.append(fruitsAndVegCategory)
        categories.append(beveragesCategory)
        categories.append(DairyProductsCategory)
        categories.append(GrainandBreadCategory)
        categories.append(HouseHoldCategory)
        categories.append(OthersCategory)
        
    }

    
    
    
    
    // MARK: - Table view data source
    
    //stating the number of sections
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return Product.categories.count
    }
    
    //giving each section a title to difrentiate between the categories
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        
        
        if section < Product.categories.count {
            return Product.categories[section]
            }
        return nil
    }
    
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        
        return categories[section].count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCellIdentifier") else{fatalError("could not dequeue the cell")}
        
        cell.textLabel?.text = categories[indexPath.section][indexPath.row].name
        
        // Configure the cell...
        return cell
    }
    
    
    @IBAction func handleRefresh(_ sender: UIRefreshControl) {
        
        Timer.scheduledTimer(withTimeInterval: 1.0 , repeats: false){
            (timer) in self.tableView.reloadData()
            self.refreshControl?.endRefreshing()
            
            self.sortingProductsCategory()
            self.tableView.reloadData()
        }
        	
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete{
            
            //removing all the products in the products array
            products.removeAll()
            
            // test purposes will be deleted
            let selected = categories[indexPath.section][indexPath.row]
            print(selected)
            
            //removing the product in the categories array
            categories[indexPath.section].remove(at: indexPath.row)
            
            //removing the rwo
            tableView.deleteRows(at: [indexPath], with: .fade)
            
            //following loops will take all the categories items and append them to the products array
            for category in categories[0]{
                products.append(category)
                
            }
            
            for category in categories[1]{
                products.append(category)
                
            }
            
            for category in categories[2]{
                products.append(category)
                
            }
            
            for category in categories[3]{
                products.append(category)
                
            }
            
            for category in categories[4]{
                products.append(category)
                
            }
            for category in categories[5]{
                products.append(category)
            }
            
            
            

            // products will be saved
            Product.saveProduct(products)
            
        }
        
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func unwindToProductsList(segue: UIStoryboardSegue) {
        guard segue.identifier == "saveUnwind" else { return }
        let sourceViewController = segue.source as! CreateNewProductTableViewController
        
        let product = sourceViewController.product
        
        products.append(product!)
        
        Product.saveProduct(products)
        
        sortingProductsCategory()
        
        tableView.reloadData()
        
        
        
    }
    
    
    
    
    
    
    
    
    
    

}
