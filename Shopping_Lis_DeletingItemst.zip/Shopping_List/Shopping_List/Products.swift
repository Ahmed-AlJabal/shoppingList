//
//  items.swift
//  Shopping_List
//
//  Created by mobileProg on 12/14/20.
//

import Foundation


struct Product : Codable {
    
    var name : String
    var quantity : Int
    var isPurchased : Bool
    var category : String
    
    static var categories: [String] = ["Fruits & Veggies","Beverages", "Dairy Products", "Grain&Bread", "House Hold", "Others"]
    
    
    static let DocumentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("products").appendingPathExtension("plist")
    
    static func loadProducts() ->[Product]?{
        guard let codedProducts = try? Data(contentsOf: ArchiveURL) else {return nil}
        let propertyListDecoder = PropertyListDecoder()
        return try? propertyListDecoder.decode(Array<Product>.self, from: codedProducts)
        
    }
    
    
    
    
    static func loadSampleProducts() ->[Product]{
        
        let product1 = Product(name:"Apple", quantity: 0, isPurchased:false, category:categories[0])
        let product2 = Product(name:"Pepsi", quantity: 0, isPurchased:false, category:categories[1])
        
        let product3 = Product(name:"Olive oil", quantity: 0, isPurchased:false, category:"Others")
        
        let product4 = Product(name:"Milk", quantity: 0, isPurchased:false, category:"Dairy Products")
        
        let product5 = Product(name:"sweet Bread", quantity: 0, isPurchased:false, category:"Grain&Bread")
        
        let product6 = Product(name:"Banana", quantity:0, isPurchased: false, category: "Fruits & Veggies")

        return [product1, product2, product3, product4, product5, product6]

    }
    
    static func saveProduct(_ products: [Product]) {
        let propertyListEncoder = PropertyListEncoder()
        let codedProducts = try? propertyListEncoder.encode(products)
        try? codedProducts?.write(to: ArchiveURL, options: .noFileProtection)
    }
    

    
}
