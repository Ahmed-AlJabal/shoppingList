//
//  CreateNewProductViewController.swift
//  Shopping_List
//
//  Created by mobileProg on 12/16/20.
//

import UIKit

class CreateNewProductViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    
    @IBOutlet weak var categoryPicker: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        categoryPicker.dataSource = self
        categoryPicker.delegate = self
    }
    
    // will set one component for each row
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // will return rows that equals to the number of categories in products
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Product.categories.count
    }
    
    // will set the title for each row component to the name of the category
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Product.categories[row]
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
